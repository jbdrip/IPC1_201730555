/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aereopuerto;

/**
 *
 * @author Jose
 */
public class Abecedario {
    public String[] abecedario = new String [26]; 

    public void llenarAbc (){
        abecedario [0] = "A";
        abecedario [1] = "B";
        abecedario [2] = "C";
        abecedario [3] = "D";
        abecedario [4] = "E";
        abecedario [5] = "F";
        abecedario [6] = "G";
        abecedario [7] = "H";
        abecedario [8] = "I";
        abecedario [9] = "J";
        abecedario [10] = "K";
        abecedario [11] = "L";
        abecedario [12] = "M";
        abecedario [13] = "N";
        abecedario [14] = "O";
        abecedario [15] = "P";
        abecedario [16] = "Q";
        abecedario [17] = "R";
        abecedario [18] = "S";
        abecedario [19] = "T";
        abecedario [20] = "U";
        abecedario [21] = "V";
        abecedario [22] = "W";
        abecedario [23] = "X";
        abecedario [24] = "Y";
        abecedario [25] = "Z";
    }
}
