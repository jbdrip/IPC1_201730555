/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aereopuerto;

import java.util.Random;

/**
 *
 * @author Jose
 */
public class Avion {
    
    private int correlativo;
    public int cantPasajeros;
    public int cantTurnosDes;
    public int cantTurnosMan;
    public int tipoMin=1, tipoMax=4;
    public String tipo;
    Random aleatorio = new Random();
     
    public Avion(int correlativo){
        
        int tipoAvion = ((int)(Math.random()*(tipoMax-tipoMin))+tipoMin);
        
        setTipo(tipoAvion);
        setCantPasajeros(tipoAvion);
        setCantTurnosDes(tipoAvion);
        setCantTurnosMan(tipoAvion);
        setCorrelativo(correlativo);
        
    }

    @Override
    public String toString() {
        return "\n"
                +"\n"+ 
                "           TIPO " +tipo+"\n"+
                "           PASAJEROS "+cantPasajeros+"\n"+
                "           DESABORDAJE "+cantTurnosDes+"\n"+
                "           MANTENIMIENTO "+cantTurnosMan+"\n"+"\n";
                
    }

    public int getCantPasajeros() {
        return cantPasajeros;
    }

    public void setCantPasajeros(int tipo) {
        int max1 = (10)+1, min1 = 5; 
        int max2 = (25)+1, min2 = 15;
        int max3 = (40)+1, min3 = 30;
        
        switch (tipo) {
            case 1:
                this.cantPasajeros=((int)(Math.random()*(max1-min1))+min1);
                break;
            case 2:
                this.cantPasajeros=((int)(Math.random()*(max2-min2))+min2);
                break;
            case 3:
                this.cantPasajeros=((int)(Math.random()*(max3-min3))+min3);
                break;
            default:
                break;
        }
    }

    public int getCantTurnosDes() {
        return cantTurnosDes;
    }

    public void setCantTurnosDes(int tipo) {
        switch (tipo){
            case 1:
                this.cantTurnosDes=1;
                break;
            case 2:
                this.cantTurnosDes=2;
                break;
            case 3:
                this.cantTurnosDes=3;
                break;
            default:
                break;
        }
    }

    public int getCantTurnosMan() {
        return cantTurnosMan;
    }

    public void setCantTurnosMan(int tipo) {
        int max1 = (3)+1, min1 = 1; 
        int max2 = (4)+1, min2 = 2;
        int max3 = (6)+1, min3 = 3;
        
        switch (tipo) {
            case 1:
                this.cantTurnosMan=((int)(Math.random()*(max1-min1))+min1);
                break;
            case 2:
                this.cantTurnosMan=((int)(Math.random()*(max2-min2))+min2);
                break;
            case 3:
                this.cantTurnosMan=((int)(Math.random()*(max3-min3))+min3);
                break;
            default:
                break;
        }
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        switch(tipo){
            case 1: 
                this.tipo="Pequeño";
                break;
            case 2:
                this.tipo="Mediano";
                break;
            case 3:
                this.tipo="Grande";
                break;
            default:
                break;
        }
    }

    public int getCorrelativo() {
        return correlativo;
    }

    public void setCorrelativo(int correlativo) {
        this.correlativo = correlativo;
    }
    
}
