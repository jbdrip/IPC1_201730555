/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aereopuerto;

import javax.swing.JTextArea;

/**
 *
 * @author Javier
 */
public class ColaAviones {
    
    public Nodo primero;
    ListaEstaciones listaEstaciones= new ListaEstaciones();
    
    public void encolar(Nodo avion) {
        Nodo aux = primero;
        if (primero == null) {
            primero = avion;
        } else {
            while (aux.sig != null) {
                aux = aux.sig;
            }
            aux.sig = avion;
        }
    }
    
    public void crearestacion(Estacion estacion){
        listaEstaciones.insertarFinal(new Nodo(estacion));
    }
    
    public void procesosmantenimiento(){
        listaEstaciones.pasarTurnoMan();
        listaEstaciones.eliminarEstacionOcupada();
    }
    
    public boolean comprobarEstacionesOcupadas(){
        Nodo aux = listaEstaciones.primero;
            while(aux != null){
                Estacion estacion  = (Estacion) aux.getDato();
                if(estacion.getEstado().equals("Libre")){
                    return false;
                }
                aux = aux.sig;
            }
        return true;
    }
    
    public void descolar() {
        if(comprobarEstacionesOcupadas()){
            return;
        }
        else{
            try{
                if (primero.sig == null) {
                    try{
                        listaEstaciones.eliminarEstacionLibre(primero);
                        primero = primero.sig = null;
                    }catch(NullPointerException e){}
                }
                else{
                    try{
                        listaEstaciones.eliminarEstacionLibre(primero);
                        primero = primero.sig;
                    }catch(NullPointerException e){}
                }
            }catch(NullPointerException e){}
        }   
    }
    
    public void recorrer(JTextArea txt) {
        if (primero == null) {
            txt.append("**********Cola de Aviones**********");
            txt.append("\nNo hay Aviones");
        } else {
            txt.append("**********Cola de Aviones**********");
            Nodo aux = primero;
            while (aux != null) {
                Avion av = (Avion) aux.getDato();
                txt.append("\nAvion " + av.getCorrelativo()
                        + "\n       Tipo: " + av.getTipo()
                        + "\n       Pasajeros: " + av.getCantPasajeros()
                        + "\n       Desabordaje: " + av.getCantTurnosDes()
                        + "\n       Mantenimiento: " + av.getCantTurnosMan());
                aux = aux.sig;
            }
            txt.append("\n");
        }
        txt.append("\n");
        listaEstaciones.recorrer(txt);
    }
    public void recorrer() {
        if (primero == null) {
            System.out.println("**********Cola de Aviones**********");
            System.out.println("\nNo hay Aviones");
        } else {
            System.out.println("**********Cola de Aviones**********");
            Nodo aux = primero;
            while (aux != null) {
                Avion av = (Avion) aux.getDato();
                System.out.println("\nAvion " + av.getCorrelativo()
                        + "\n       Tipo: " + av.getTipo()
                        + "\n       Pasajeros: " + av.getCantPasajeros()
                        + "\n       Desabordaje: " + av.getCantTurnosDes()
                        + "\n       Mantenimiento: " + av.getCantTurnosMan());
                aux = aux.sig;
            }
            System.out.println("\n");
        }
        System.out.println("\n");
        listaEstaciones.recorrer();
    }
    
    


}
