/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aereopuerto;

import javax.swing.JTextArea;

/**
 *
 * @author Jose
 */
public class ColaEscritorios {
    public Nodo primero;
    public String id;
    ListaEscritorios listaEscritorios= new ListaEscritorios();
    
    public void encolar(Nodo pasajero) {
        Nodo aux = primero;
        if (primero == null) {
            primero = pasajero;
        } else {
            while (aux.sig != null) {
                aux = aux.sig;
            }
            aux.sig = pasajero;
        }
    }

    public void descolar() {
        if(comprobarEscritoriosLlenos()){
            return;
        }
        else{
        try{
        if (primero.sig == null) {
            try{
            listaEscritorios.eliminarEscritorioLibre(primero);
            primero = primero.sig = null;
            }catch(NullPointerException e){}
        } else {
            try{
            listaEscritorios.eliminarEscritorioLibre(primero);
            primero = primero.sig;
            }catch(NullPointerException e){}
        }
        }catch(NullPointerException e){}
        
        }
    }
    
    public boolean comprobarEscritoriosLlenos(){
        Nodo aux = listaEscritorios.primero;
        while(aux!=null){
            Escritorio escritorio = (Escritorio) aux.getDato();
            if(escritorio.getEstado().equals("Libre")){
                return false;
            }
            aux = aux.sig;
        }
        return true;
    }
    
    public void eliminarEspacioLibre(Nodo pasajero) {
        Nodo actualEspacio = primero;
        while (actualEspacio != null) {
            EspacioColaEscritorio aux = (EspacioColaEscritorio) actualEspacio.getDato();
            Pasajero encola = (Pasajero) pasajero.getDato();
            if (aux.getEstado().equals("Libre")) {
                aux.setEstado("Ocupado");
                aux.setNumPasajero(encola.getCorrelativo());
                aux.setCantDoc(encola.getCantDoc());
                aux.setCantMaletas(encola.getCantMaletas());
                aux.setTurnosRegistro(encola.getTurnosRegistro());
                actualEspacio = null;
            } else {
                actualEspacio = actualEspacio.sig;
            }
        }
    }
    
    public void eliminarEspacioOcupado() {
        Nodo actual = primero;
        while (actual != null) {
            Estacion aux = (Estacion) actual.getDato();
            if ((aux.getEstado().equals("Ocupado")) && (aux.getMantenimiento() == 0)) {
                aux.setEstado("Libre");
                aux.setNumAvion(0);
                aux.setTipo("");
                aux.setPasajeros(0);
                aux.setTurnosDesabordaje(0);
                aux.setMantenimiento(0);
                actual = null;
            } else {
                actual = actual.sig;
            }
        }
    }
    
    public void recorrer(JTextArea txt) {
        if (primero == null) {
            txt.append("**********Cola de Escritorio "+id+"**********");
            txt.append("\nNo hay pasajeros");
        } else {
            txt.append("**********Cola de Escritorio "+id+"**********");
            Nodo aux = primero;
            while (aux != null) {
                EspacioColaEscritorio espacio = (EspacioColaEscritorio)aux.getDato();
                txt.append("\nEspacio " + espacio.getCorrelativo()
                        + "\n       Estado: " + espacio.getEstado()
                        + "\n       Pasajero: " + espacio.getNumPasajero()
                        + "\n       Documentos: " + espacio.getCantDoc()
                        + "\n       Turnos de registro: " + espacio.getTurnosRegistro());
                aux = aux.sig;
            }
            txt.append("\n");
        }
        txt.append("\n");
    }
}
