/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aereopuerto;

import javax.swing.JTextArea;

/**
 *
 * @author Javier
 */
public class ColaPasajeros {

    int cantmaletas;
    int maletasEliminadas = 1;
    public Nodo primero;
    ListaMaletas listaMaletas = new ListaMaletas();
    ListaEscritorios listaEscritorios = new ListaEscritorios();
    ColaEscritorios colaEscritorios = new ColaEscritorios();
    
    public void encolar(Nodo nuevo) {
        Nodo aux = primero;
        if (primero == null) {
            primero = nuevo;
            Pasajero pas = (Pasajero) primero.getDato();
            cantmaletas = pas.getCantMaletas();
            System.out.println(cantmaletas);
            for (int i = 1; i <= cantmaletas; i++) {
                listaMaletas.insertar(new Nodo(new Maleta(i)));
            }
            cantmaletas++;
        } else {
            int cantmaletas2 = cantmaletas - 1;
            while (aux.sig != null) {
                aux = aux.sig;
            }
            aux.sig = nuevo;
            Pasajero p = (Pasajero) aux.sig.getDato();
            cantmaletas2 = cantmaletas2 + p.getCantMaletas();
            for (; cantmaletas <= cantmaletas2; cantmaletas++) {
                listaMaletas.insertar(new Nodo(new Maleta(cantmaletas)));
            }
        }

    }
    
    public void crearEscritorio(Escritorio escritorio){
        listaEscritorios.insertarFinal(new Nodo(escritorio));
    }
    
    public void procesosmantenimiento(){
        
        listaEscritorios.pasarTurnoRegistro();
        listaEscritorios.eliminarEscritorioOcupado();
    }

    public void descolar() {
        if(comprobarEscritoriosLlenos()){
            try{
                if (primero.sig == null) {
                    try{
                        listaEscritorios.primero.colaEscritorio.eliminarEspacioLibre(primero);
                        primero = primero.sig = null;
                        listaMaletas.eliminar(maletasEliminadas);
                        maletasEliminadas++;
                        listaMaletas.eliminar(maletasEliminadas);
                        maletasEliminadas++;
                        listaMaletas.eliminar(maletasEliminadas);
                        maletasEliminadas++;
                        listaMaletas.eliminar(maletasEliminadas);
                        maletasEliminadas++;
                        listaMaletas.eliminar(maletasEliminadas);
                        maletasEliminadas++;
                    }catch(NullPointerException e){}
                }
                else {
                    try{
                        listaEscritorios.primero.colaEscritorio.eliminarEspacioLibre(primero);
                        Pasajero pasajero = (Pasajero) primero.getDato();
                        for (int i = 1; i <= pasajero.getCantMaletas(); i++) {
                            listaMaletas.eliminar(maletasEliminadas);
                            maletasEliminadas++;
                        }
                        primero = primero.sig;
                    }catch(NullPointerException e){}
                }
            }catch(NullPointerException e){}
        }
        else{
            try{
                if (primero.sig == null) {
                    try{
                        listaEscritorios.eliminarEscritorioLibre(primero);
                        primero = primero.sig = null;
                        listaMaletas.eliminar(maletasEliminadas);
                        maletasEliminadas++;
                        listaMaletas.eliminar(maletasEliminadas);
                        maletasEliminadas++;
                        listaMaletas.eliminar(maletasEliminadas);
                        maletasEliminadas++;
                        listaMaletas.eliminar(maletasEliminadas);
                        maletasEliminadas++;
                        listaMaletas.eliminar(maletasEliminadas);
                        maletasEliminadas++;
                    }catch(NullPointerException e){}
                }
                else {
                    try{
                        listaEscritorios.eliminarEscritorioLibre(primero);
                        Pasajero pasajero = (Pasajero) primero.getDato();
                        for (int i = 1; i <= pasajero.getCantMaletas(); i++) {
                            listaMaletas.eliminar(maletasEliminadas);
                            maletasEliminadas++;
                        }
                        primero = primero.sig;
                    }catch(NullPointerException e){}
                }
            }catch(NullPointerException e){}
        }  
    }
    
    public void descolarMaletas() {
        try{
        if (primero.sig == null) {
            primero = primero.sig = null;
            try {
                listaMaletas.eliminar(maletasEliminadas);
                maletasEliminadas++;
                listaMaletas.eliminar(maletasEliminadas);
                maletasEliminadas++;
                listaMaletas.eliminar(maletasEliminadas);
                maletasEliminadas++;
                listaMaletas.eliminar(maletasEliminadas);
                maletasEliminadas++;
                listaMaletas.eliminar(maletasEliminadas);
                maletasEliminadas++;
            } catch (Exception e) {
            }
        } else {
            Pasajero pasajero = (Pasajero) primero.getDato();
            for (int i = 1; i <= pasajero.getCantMaletas(); i++) {
                listaMaletas.eliminar(maletasEliminadas);
                maletasEliminadas++;
            }
            primero = primero.sig;
        }
        }catch(Exception e){}
    }
    
    public void eliminar() {
        try{
        if (primero != null) {
            Nodo aux = primero;
            Nodo antaux = null;
            while (aux != null) {
                Nodo auxiliar = listaEscritorios.primero;
                Pasajero pasajero = (Pasajero) aux.getDato();
                if (pasajero.eliminar == 0) {
                    if (antaux == null) {
                        while(auxiliar!=null){
                           if(comprobarColaLlena(auxiliar)){
                                EspacioColaEscritorio espacio = (EspacioColaEscritorio) auxiliar.sig.getDato();
                                espacio.setEstado("Ocupado");
                                espacio.setCantDoc(pasajero.getCantDoc());
                                espacio.setCantMaletas(pasajero.getCantMaletas());
                                espacio.setNumPasajero(pasajero.getCorrelativo());
                                espacio.setTurnosRegistro(pasajero.getTurnosRegistro());
                            }
                           else{
                                EspacioColaEscritorio espacio = (EspacioColaEscritorio) auxiliar.getDato();
                                espacio.setEstado("Ocupado");
                                espacio.setCantDoc(pasajero.getCantDoc());
                                espacio.setCantMaletas(pasajero.getCantMaletas());
                                espacio.setNumPasajero(pasajero.getCorrelativo());
                                espacio.setTurnosRegistro(pasajero.getTurnosRegistro());
                           }
                           auxiliar = auxiliar.sig;
                        }
                        primero = primero.sig;
                        aux.sig = null;
                        aux = primero;
                    } else {
                        antaux.sig = aux.sig;
                        aux.sig = null;
                        aux = antaux.sig;
                        aux.ant = antaux;
                    }
                }
                else{
                    antaux = aux;
                    aux = aux.sig;
                }
                    
            }
        }
        }catch(Exception e){}
    }

    public void recorrer(JTextArea txt) {
        if (primero == null) {
            txt.append("**********Pasajeros**********");
            txt.append("\nNo hay pasajeros");
        } else {
            txt.append("**********Pasajeros**********");
            Nodo aux = primero;
            while (aux != null) {
                Pasajero p = (Pasajero) aux.getDato();
                txt.append("\nPasajero: " + p.getCorrelativo()
                        + "\n       Maletas: " + p.getCantMaletas()
                        + "\n       Documentos: " + p.getCantDoc()
                        + "\n       Turnos de registro: " + p.getTurnosRegistro());
                aux = aux.sig;
            }
            txt.append("\n");
        }
        txt.append("\n");
        listaMaletas.recorrer(txt);
        txt.append("\n");
        listaEscritorios.recorrer(txt);
    }
    public void recorrer() {
        if (primero == null) {
            System.out.println("**********Pasajeros**********");
            System.out.println("\nNo hay pasajeros");
        } else {
            System.out.println("**********Pasajeros**********");
            Nodo aux = primero;
            while (aux != null) {
                Pasajero p = (Pasajero) aux.getDato();
                System.out.println("\nPasajero: " + p.getCorrelativo()
                        + "\n       Maletas: " + p.getCantMaletas()
                        + "\n       Documentos: " + p.getCantDoc());
                aux = aux.sig;
            }
            System.out.println("\n");
        }
        System.out.println("\n");
        listaMaletas.recorrer();
    }
    
    public boolean comprobarEscritoriosLlenos(){
        Nodo aux = listaEscritorios.primero;
        while(aux!=null){
            Escritorio escritorio = (Escritorio) aux.getDato();
            if(escritorio.getEstado().equals("Libre")){
                return false;
            }
            aux = aux.sig;
        }
        return true;
    }
    public boolean comprobarColaLlena(Nodo escritorio){
        Nodo aux = escritorio;
            while(aux != null){
                Nodo aux2 = aux.colaEscritorio.primero;
                while(aux2!=null){
                    EspacioColaEscritorio espacio  = (EspacioColaEscritorio) aux2.getDato();
                    if(espacio.getEstado().equals("Libre")){
                        return false;
                    }
                    aux2 = aux2.sig;
                }
                aux = aux.sig;
            }
        return true;
    }
}
