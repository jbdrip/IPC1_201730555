/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aereopuerto;

/**
 *
 * @author Jose
 */
public class Escritorio {
    private String id;
    public int pasajero;
    public String Estado;
    public int cantDoc;
    public int cantTurnos;
    
    public Escritorio(String id, Pasajero pasajero){
        setId(id);
        setPasajero(pasajero.getCorrelativo());
        setEstado("Ocupado");
        setCantDoc(pasajero.getCantDoc());
        setCantTurnos(pasajero.getTurnosRegistro());
    }
    
    public Escritorio(String id){
        setId(id);
        setPasajero(0);
        setEstado("Libre");
        setCantDoc(0);
        setCantTurnos(0);
    }

    public String getEstado() {
        return Estado;
    }

    public int getPasajero() {
        return pasajero;
    }

    public void setPasajero(int pasajero) {
        this.pasajero = pasajero;
    }

    public void setEstado(String Estado) {
        this.Estado = Estado;
    }

    public int getCantDoc() {
        return cantDoc;
    }

    public void setCantDoc(int cantDoc) {
        this.cantDoc = cantDoc;
    }

    public int getCantTurnos() {
        return cantTurnos;
    }

    public void setCantTurnos(int cantTurnos) {
        this.cantTurnos = cantTurnos;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    
}
