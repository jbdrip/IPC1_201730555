/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aereopuerto;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author joses
 */
public class Graficador {

    public void crearDotAvion(Nodo primero, String nombre) {
        FileWriter fw = null;
        PrintWriter pw = null;

        try {
            fw = new FileWriter(nombre + ".dot");

            pw = new PrintWriter(fw);
            pw.println("digraph listadobleAviones {");
            pw.println(genDotAvion(primero));
            pw.println("}");
            pw.close();
        } catch (IOException ex) {
            System.out.println("puto el que lo lea jeje :)" + ex);
        } finally {
            try {
                fw.close();
            } catch (IOException e) {}
        }
    }

    public String genDotAvion(Nodo primero) {
          
        String cadena = "";

        if (primero == null) {
            return cadena;
        }
        Avion avion = (Avion) primero.getDato();  
        cadena += "nodo" + reemplazar(primero.hashCode())
                + "[label=\""
                + "Avion "+avion.getCorrelativo()
                + ":"
                + avion.getTipo()
                + "\"];\n";

        if (primero.sig != null) {

            cadena += "nodo"
                    + reemplazar(primero.hashCode())
                    + "->" + "nodo"
                    + reemplazar(primero.sig.hashCode()) + ";\n";

            cadena += "nodo" + reemplazar(primero.sig.hashCode())
                    + "->" + "nodo"
                    + reemplazar(primero.sig.ant.hashCode()) + ";\n";

            cadena += genDotAvion(primero.sig);
        }
        return cadena;
    }
    
    public void crearDotPasajero(Nodo primero, String nombre) {
        FileWriter fw = null;
        PrintWriter pw = null;

        try {
            fw = new FileWriter(nombre + ".dot");

            pw = new PrintWriter(fw);
            pw.println("digraph colaPasajeros {");
            pw.println(genDotPasajero(primero));
            pw.println("}");
            pw.close();
        } catch (IOException ex) {
            System.out.println("puto el que lo lea jeje :)" + ex);
        } finally {
            try {
                fw.close();
            } catch (IOException e) {}
        }
    }

    public String genDotPasajero(Nodo primero) {
          
        String cadena = "";

        if (primero == null) {
            return cadena;
        }
        Pasajero pasajero = (Pasajero) primero.getDato();
        cadena += "nodo" + reemplazar(primero.hashCode())
                + "[label=\""
                + "Pasajero "
                + ":"
                + pasajero.getCorrelativo()
                + "\"];\n";

        if (primero.sig != null) {

            cadena += "nodo"
                    + reemplazar(primero.hashCode())
                    + "->" + "nodo"
                    + reemplazar(primero.sig.hashCode()) + ";\n";

//            cadena += "nodo" + reemplazar(primero.sig.hashCode())
//                    + "->" + "nodo"
//                    + reemplazar(primero.sig.hashCode()) + ";\n";

            cadena += genDotPasajero(primero.sig);
        }
        return cadena;
    }
    
    public void crearDotColaEscritorio(Nodo primero, String nombre) {
        FileWriter fw = null;
        PrintWriter pw = null;

        try {
            fw = new FileWriter(nombre + ".dot");

            pw = new PrintWriter(fw);
            pw.println("digraph colaEscritorio {");
            pw.println(genDotColaEscritorio(primero));
            pw.println("}");
            pw.close();
        } catch (IOException ex) {
            System.out.println("puto el que lo lea jeje :)" + ex);
        } finally {
            try {
                fw.close();
            } catch (IOException e) {}
        }
    }

    public String genDotColaEscritorio(Nodo primero) {
          
        String cadena = "";

        if (primero == null) {
            return cadena;
        }
        EspacioColaEscritorio pasajero = (EspacioColaEscritorio) primero.getDato();
        cadena += "nodo" + reemplazar(primero.hashCode())
                + "[label=\""
                + "Espacio " +pasajero.getCorrelativo()
                + " : " + "Pasajero "
                + pasajero.getNumPasajero()
                + "\"];\n";

        if (primero.sig != null) {

            cadena += "nodo"
                    + reemplazar(primero.hashCode())
                    + "->" + "nodo"
                    + reemplazar(primero.sig.hashCode()) + ";\n";

//            cadena += "nodo" + reemplazar(primero.sig.hashCode())
//                    + "->" + "nodo"
//                    + reemplazar(primero.sig.hashCode()) + ";\n";

            cadena += genDotColaEscritorio(primero.sig);
        }
        return cadena;
    }
    
    public void crearDotColaAviones(Nodo primero, String nombre) {
        FileWriter fw = null;
        PrintWriter pw = null;

        try {
            fw = new FileWriter(nombre + ".dot");

            pw = new PrintWriter(fw);
            pw.println("digraph colaAviones {");
            pw.println(genDotColaAviones(primero));
            pw.println("}");
            pw.close();
        } catch (IOException ex) {
            System.out.println("puto el que lo lea jeje :)" + ex);
        } finally {
            try {
                fw.close();
            } catch (IOException e) {}
        }
    }

    public String genDotColaAviones(Nodo primero) {
          
        String cadena = "";

        if (primero == null) {
            return cadena;
        }
        Avion avion = (Avion) primero.getDato();
        cadena += "nodo" + reemplazar(primero.hashCode())
                + "[label=\""
                + "Avion "+avion.getCorrelativo()
                + ":"
                + avion.getTipo()
                + "\"];\n";

        if (primero.sig != null) {

            cadena += "nodo"
                    + reemplazar(primero.hashCode())
                    + "->" + "nodo"
                    + reemplazar(primero.sig.hashCode()) + ";\n";

//            cadena += "nodo" + reemplazar(primero.sig.hashCode())
//                    + "->" + "nodo"
//                    + reemplazar(primero.sig.hashCode()) + ";\n";

            cadena += genDotColaAviones(primero.sig);
        }
        return cadena;
    }
    
    public void crearDotMaletas(Nodo primero, String nombre) {
        FileWriter fw = null;
        PrintWriter pw = null;

        try {
            fw = new FileWriter(nombre + ".dot");

            pw = new PrintWriter(fw);
            pw.println("digraph listadobleMaletas {");
            pw.println(genDotMaletas(primero));
            pw.println("}");
            pw.close();
        } catch (IOException ex) {
            System.out.println("puto el que lo lea jeje :)" + ex);
        } finally {
            try {
                fw.close();
            } catch (IOException e) {}
        }
    }

    public String genDotMaletas(Nodo primero) {
          
        String cadena = "";

        if (primero == null) {
            return cadena;
        }
        Maleta maleta = (Maleta) primero.getDato();
        cadena += "nodo" + reemplazar(primero.hashCode())
                + "[label=\""
                +"Maleta "
                + maleta.getCorrelativo()
                + "\"];\n";

        if (primero.sig != null) {

            cadena += "nodo"
                    + reemplazar(primero.hashCode())
                    + "->" + "nodo"
                    + reemplazar(primero.sig.hashCode()) + ";\n";

            cadena += "nodo" + reemplazar(primero.sig.hashCode())
                    + "->" + "nodo"
                    + reemplazar(primero.sig.ant.hashCode()) + ";\n";

            cadena += genDotMaletas(primero.sig);
        }
        return cadena;
    }
    
    public void crearDotEscritorios(Nodo primero, String nombre) {
        FileWriter fw = null;
        PrintWriter pw = null;

        try {
            fw = new FileWriter(nombre + ".dot");

            pw = new PrintWriter(fw);
            pw.println("digraph listadobleEscritorios {");
            pw.println(genDotEscritorios(primero));
            pw.println("}");
            pw.close();
        } catch (IOException ex) {
            System.out.println("puto el que lo lea jeje :)" + ex);
        } finally {
            try {
                fw.close();
            } catch (IOException e) {}
        }
    }

    public String genDotEscritorios(Nodo primero) {
          
        String cadena = "";

        if (primero == null) {
            return cadena;
        }
        Escritorio escritorio = (Escritorio) primero.getDato();  
        cadena += "nodo" + reemplazar(primero.hashCode())
                + "[label=\""
                + "Escritorio "+escritorio.getId()
                + ":"
                + escritorio.getEstado()
                + "\"];\n";

        if (primero.sig != null) {

            cadena += "nodo"
                    + reemplazar(primero.hashCode())
                    + "->" + "nodo"
                    + reemplazar(primero.sig.hashCode()) + ";\n";

            cadena += "nodo" + reemplazar(primero.sig.hashCode())
                    + "->" + "nodo"
                    + reemplazar(primero.sig.ant.hashCode()) + ";\n";

            cadena += genDotEscritorios(primero.sig);
        }
        return cadena;
    }
    
    public void crearDotEstaciones(Nodo primero, String nombre) {
        FileWriter fw = null;
        PrintWriter pw = null;

        try {
            fw = new FileWriter(nombre + ".dot");

            pw = new PrintWriter(fw);
            pw.println("digraph listaEstaciones {");
            pw.println(genDotEstaciones(primero));
            pw.println("}");
            pw.close();
        } catch (IOException ex) {
            System.out.println("puto el que lo lea jeje :)" + ex);
        } finally {
            try {
                fw.close();
            } catch (IOException e) {}
        }
    }

    public String genDotEstaciones(Nodo primero) {
          
        String cadena = "";

        if (primero == null) {
            return cadena;
        }
        Estacion estacion = (Estacion) primero.getDato();
        cadena += "nodo" + reemplazar(primero.hashCode())
                + "[label=\""
                + "Estacion " +estacion.getCorrelativo()
                + ":"
                + estacion.getEstado()
                + "\"];\n";

        if (primero.sig != null) {

            cadena += "nodo"
                    + reemplazar(primero.hashCode())
                    + "->" + "nodo"
                    + reemplazar(primero.sig.hashCode()) + ";\n";

//            cadena += "nodo" + reemplazar(primero.sig.hashCode())
//                    + "->" + "nodo"
//                    + reemplazar(primero.sig.hashCode()) + ";\n";

            cadena += genDotEstaciones(primero.sig);
        }
        return cadena;
    }

    public String reemplazar(int posMemory) {

        String cadena = String.valueOf(posMemory);

        return cadena.replace("-", "_");
    }

    
    public void genImagen(String dirDot, String dirImagen) {

        String doPath = "C:\\Program Files (x86)\\Graphviz2.38\\bin\\dot.exe";
        String cmd = doPath + " -Tjpg " + dirDot + " -o " + dirImagen;

        try {
            Runtime.getRuntime().exec(cmd);
        } catch (IOException ex) {
            System.out.println("hola");
        }
    }
}
