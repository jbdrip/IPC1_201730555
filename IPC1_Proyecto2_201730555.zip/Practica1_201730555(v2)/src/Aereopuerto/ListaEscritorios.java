/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aereopuerto;

import javax.swing.JTextArea;

/**
 *
 * @author Javier
 */
public class ListaEscritorios {
    public Nodo primero;
    
    public void insertarFinal(Nodo nuevo) {
        Nodo aux = primero;
        if (primero == null) {
            primero = nuevo;
        } else {
            while (aux.sig != null) {
                aux = aux.sig;
            }
            aux.sig = nuevo;
            nuevo.ant = aux;
        }
    }
    
    public void crearEscritorios(Escritorio escritorio){
        this.insertarFinal(new Nodo(escritorio));
    }
    
    public void eliminarEscritorioLibre(Nodo pasajero) {
        Nodo actualEscritorio = primero;
        while (actualEscritorio != null) {
            Escritorio aux = (Escritorio) actualEscritorio.getDato();
            Pasajero encola = (Pasajero) pasajero.getDato();
            if (aux.getEstado().equals("Libre")) {
                aux.setEstado("Ocupado");
                aux.setPasajero(encola.getCorrelativo());
                aux.setCantDoc(encola.getCantDoc());
                aux.setCantTurnos(encola.getTurnosRegistro());
                actualEscritorio = null;
            } else {
                actualEscritorio = actualEscritorio.sig;
            }
        }
    }

    public void pasarTurnoRegistro() {
        if (primero == null) {
            System.out.println("No hay escritorios");
        } else {
            Nodo aux = primero;
            while (aux != null) {
                Escritorio escritorio = (Escritorio) aux.getDato();
                if(escritorio.getEstado().equals("Ocupado")){
                escritorio.cantTurnos=(escritorio.cantTurnos-1);
                }
                aux = aux.sig;
            }
        }
    }

    public void eliminarEscritorioOcupado() {
        Nodo actual = primero;
        while (actual != null) {
            Escritorio aux = (Escritorio) actual.getDato();
            if ((aux.getEstado().equals("Ocupado")) && (aux.getCantTurnos()<= 0)) {
                aux.setEstado("Libre");
                aux.setPasajero(0);
                aux.setCantTurnos(0);
                aux.setCantDoc(0);
                actual = null;
            } else {
                actual = actual.sig;
            }
        }
    }
    
    public void recorrer(JTextArea txt) {
        if (primero == null) {
            txt.append("**********Escritorios de registro**********");
            txt.append("\nNo hay Escritorios");
        } else {
            Nodo escritorio = primero;
            txt.append("**********Escritorios de registro**********");
            while (escritorio!= null) {
                Escritorio aux = (Escritorio) escritorio.getDato();
                escritorio.colaEscritorio.id=aux.getId();
                txt.append("\nEscritorio: " + aux.getId()
                        + "\n       Estado: " + aux.getEstado()
                        + "\n       Pasajero: " + aux.getPasajero()
                        + "\n       Documentos: " + aux.getCantDoc()
                        + "\n       Turnos: " + aux.getCantTurnos()
                        + "\n\n");
                escritorio.colaEscritorio.recorrer(txt);
                txt.append("\n");
                escritorio.pilaEscritorio.recorrer(txt);
                escritorio = escritorio.sig;
            }
            txt.append("\n");
        }
    }
}
