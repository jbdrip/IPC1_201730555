/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aereopuerto;

import javax.swing.JTextArea;

/**
 *
 * @author Javier
 */
public class ListaMaletas {

    public Nodo primero;
    public Nodo ultimo;

    public void insertar(Nodo nuevo) {
        if (primero == null) {
            primero = nuevo;
            primero.sig = nuevo;
            primero.ant = primero;
        } else {
            Nodo aux = primero;
            while (aux.sig != primero) {
                aux = aux.sig;
            }
            aux.sig = nuevo;
            nuevo.ant = aux;
            nuevo.sig = primero;
            primero.ant = nuevo;
        }
    }
    public void eliminarNodo(int maleta){
        Nodo actual;
        Nodo anterior;
        actual = primero;
        anterior = ultimo;
        do{
            Maleta aux = (Maleta) actual.getDato();
            if(aux.getCorrelativo()==maleta){
                if(actual==primero){
                    primero=primero.sig;
                    ultimo.sig=primero;
                    primero.ant=ultimo;
                }else if(actual==ultimo){
                    ultimo=anterior;
                    primero.ant = ultimo;
                    ultimo.sig=primero;
                }else{
                    anterior.sig=actual.sig;
                    actual.sig.ant=anterior;
                }
            }
          anterior = actual;
          actual= actual.sig;
        }while(actual!=primero);
        
    }
    public void eliminar(int maleta) {
        if (primero != null) {
            Nodo aux = primero;
            Nodo ant = null;
            while (aux.sig != primero) {
                Maleta m = (Maleta) aux.getDato();
                if (m.getCorrelativo() == maleta) {
                    if (ant == null) {
                        if (aux.sig == primero) {
                            primero = null;
                        } else {
                            ant = aux.ant;
                            ant.sig = aux.sig;
                            aux = aux.sig;
                            aux.ant = ant;
                            primero = aux;
                            ant = null;
                        }
                    } else {
                        aux.ant = null;
                        ant.sig = aux.sig;
                        aux = aux.sig;
                        aux.ant = ant;
                    }
                } else {
                    ant = aux;
                    aux = aux.sig;
                }
            }
            Maleta m = (Maleta) aux.getDato();
            if (m.getCorrelativo() == maleta) {
                ant.sig = primero;
                primero.ant = ant;
                aux = null;
            }

        } else {
            System.out.println("LISTA VACIA");
        }
    }

     public void recorrer(JTextArea txt) {
        if (primero == null) {
            txt.append("**********Maletas**********");
            txt.append("\nNo hay maletas");
        } else {
            txt.append("**********Maletas**********");
            Nodo aux = primero;
            Maleta mAux = (Maleta) aux.getDato();
            int fin;
            txt.append("\nInicio: "+mAux.getCorrelativo());
            do {
                aux = aux.sig;
                Maleta m = (Maleta) aux.ant.getDato();
                fin= m.getCorrelativo();
            } while (aux != primero);
            txt.append("\nFin: "+fin);
            Nodo auxx = primero;
            do {
                Maleta mAux2 = (Maleta) auxx.getDato();
                txt.append("\nMaleta: "+mAux2.getCorrelativo());
                auxx = auxx.sig;
            } while (auxx != primero);
            txt.append("\n");
        }
    }
     
     public void recorrer() {
        if (primero == null) {
            System.out.println("**********Maletas**********");
            System.out.println("\nNo hay maletas");
        } else {
            System.out.println("**********Maletas**********");
            Nodo aux = primero;
            Maleta m = (Maleta) aux.getDato();
            int fin = 0;
            System.out.println("\nInicio: "+m.getCorrelativo());
            do {
                aux = aux.sig;
                Maleta m2 = (Maleta) aux.ant.getDato();
                fin= m2.getCorrelativo();
            } while (aux != primero);
            System.out.println("\nFin: "+fin);
            Nodo auxx = primero;
            do {
                Maleta m3 = (Maleta) auxx.getDato();
                System.out.println("\nMaleta: "+m3.getCorrelativo());
                auxx = auxx.sig;
            } while (auxx != primero);
            System.out.println("\n");
        }
    }

}
