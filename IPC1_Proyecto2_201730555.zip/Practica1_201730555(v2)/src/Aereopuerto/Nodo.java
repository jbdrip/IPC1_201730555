/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aereopuerto;

/**
 *
 * @author Jose
 */
public class Nodo {
    
    public Object dato;
    public Nodo sig;
    public Nodo ant;
    
    public PilaEscritorios pilaEscritorio = new PilaEscritorios();
    public ColaEscritorios colaEscritorio = new ColaEscritorios();
    
     public Nodo(Object dato, Nodo sig, Nodo ant){
        setDato(dato);
        setSiguiente(sig);
        setAnterior(ant);
    }
    
    public Nodo(Object dato, Nodo sig){
        setDato(dato);
        setSiguiente(sig);
    }
    public Nodo(Object dato){
        setDato(dato);
        setSiguiente(null);
        setAnterior(null);
    }

    public Object getDato() {
        return dato;
    }

    public void setDato(Object dato) {
        this.dato = dato;
    }
    
    public Nodo getSiguiente() {
        return sig;
    }

    public void setSiguiente(Nodo sig) {
        this.sig = sig;
    }

    @Override
    public String toString() {
        return (String)dato;
    }

    public Nodo getAnterior() {
        return ant;
    }

    public void setAnterior(Nodo ant) {
        this.ant = ant;
    }
}
