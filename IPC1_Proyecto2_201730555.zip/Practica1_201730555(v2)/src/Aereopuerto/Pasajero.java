/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aereopuerto;

/**
 *
 * @author Jose
 */
public class Pasajero {
    
    private int correlativo;
    public int cantMaletas;
    public int cantDoc; 
    public int turnosRegistro;
    public int eliminar=0;
    public int maxMaletas=5, minMaletas=1;
    public int maxDoc=11, minDoc=1;
    public int maxTurnos=4, minTurnos=1;
    
    public Pasajero(int correlativo){
        
        int maletas = ((int)(Math.random()*(maxMaletas-minMaletas))+minMaletas);
        int doc = ((int)(Math.random()*(maxDoc-minDoc))+minDoc);
        int turnos = ((int)(Math.random()*(maxTurnos-minTurnos))+minTurnos);
        
        setCantMaletas(maletas);
        setCantDoc(doc);
        setTurnosRegistro(turnos);
        setCorrelativo(correlativo);
    }

    public int getCorrelativo() {
        return correlativo;
    }

    public void setCorrelativo(int correlativo) {
        this.correlativo = correlativo;
    }

    @Override
    public String toString() {
        return "********** PASAJEROS **********\n"+
               "\n"+
                "           MALETAS "+cantMaletas+"\n"+
                "           DOCUMENTOS"+cantDoc+ "\n"+"\n";
    }

    public int getCantMaletas() {
        return cantMaletas;
    }

    public void setCantMaletas(int cantMaletas) {
        this.cantMaletas = cantMaletas;
    }

    public int getCantDoc() {
        return cantDoc;
    }

    public void setCantDoc(int cantDoc) {
        this.cantDoc = cantDoc;
    }

    public int getTurnosRegistro() {
        return turnosRegistro;
    }

    public void setTurnosRegistro(int turnosRegistro) {
        this.turnosRegistro = turnosRegistro;
    }
    
    
    
}
