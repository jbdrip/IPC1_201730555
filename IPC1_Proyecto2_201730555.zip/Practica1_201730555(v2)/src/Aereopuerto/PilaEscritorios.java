/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aereopuerto;

import javax.swing.JTextArea;

/**
 *
 * @author Jose
 */
public class PilaEscritorios {
    public Nodo primero;
    
    public void push(Nodo escritorio) {
        Nodo aux = primero;
        if (primero == null) {
            primero = escritorio;
        } else {
            while (aux.sig != null) {
                aux = aux.sig;
            }
            aux.sig = escritorio;
        }
    }
    
    public void recorrer(JTextArea txt) {
        if (primero == null) {
            txt.append("**********Documentos**********");
            txt.append("\nNo hay documentos");
        } else {
            txt.append("**********Documentos**********");
            Nodo aux = primero;
            while (aux != null) {
                int documentos = (int) aux.getDato();
                txt.append("\nCantidad de documentos " + documentos);
                aux = aux.sig;
            }
            txt.append("\n");
        }
        txt.append("\n");
        
    }
}
