/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aereopuerto;

/**
 *
 * @author Javier
 */
public class Prueba {
    public static void main(String[] args) {
        ColaPasajeros c = new ColaPasajeros();
        Frame p = new Frame();
        p.setVisible(true);
        
    }
    
}
