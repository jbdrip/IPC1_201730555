/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aereopuerto;

/**
 *
 * @author Jose
 */
public class Estacion {
    private int correlativo;
    public String estado;
    public Avion avion;
    public int numAvion;
    public String tipo;
    public int pasajeros;
    public int turnosDesabordaje;
    public int mantenimiento;
    
    public Estacion(int correlativo){
        setCorrelativo(correlativo);
        setEstado("Libre");
        setNumAvion(0);
        setTipo("");
        setPasajeros(0);
        setTurnosDesabordaje(0);
        setMantenimiento(0);
    }
    
    public Estacion(int correlativo, Avion avion){
        setCorrelativo(correlativo);
        setAvion(avion);
        setEstado("Ocupado");
        setNumAvion(avion.getCorrelativo());
        setTipo(avion.getTipo());
        setPasajeros(avion.getCantPasajeros());
        setTurnosDesabordaje(avion.getCantTurnosDes());
        setMantenimiento(avion.getCantTurnosMan());
        
    }

    public int getCorrelativo() {
        return correlativo;
    }

    public void setCorrelativo(int correlativo) {
        this.correlativo = correlativo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Avion getAvion() {
        return avion;
    }

    public void setAvion(Avion avion) {
        this.avion = avion;
    }
    
    public int getNumAvion() {
        return numAvion;
    }

    public void setNumAvion(int numAvion) {
        this.numAvion = numAvion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getPasajeros() {
        return pasajeros;
    }

    public void setPasajeros(int pasajeros) {
        this.pasajeros = pasajeros;
    }

    public int getTurnosDesabordaje() {
        return turnosDesabordaje;
    }

    public void setTurnosDesabordaje(int turnosDesabordaje) {
        this.turnosDesabordaje = turnosDesabordaje;
    }

    public int getMantenimiento() {
        return mantenimiento;
    }

    public void setMantenimiento(int mantenimiento) {
        this.mantenimiento = mantenimiento;
    }
    

//    @Override
//    public String toString() {
//        if(estacionVacia==false){
//            return "********** ESTACIONES **********\n"+
//               "\n"+
//               "            ESTADO "+estado+"\n"+
//               "            TIPO "+avion.getTipo()+"\n"+
//               "            PASAJEROS "+avion.getCantPasajeros()+"\n"+
//               "            DESABORDAJE "+avion.getCantTurnosDes()+"\n"+
//               "            MANTENIMIENTO "+avion.getCantTurnosMan()+"\n\n";
//        }
//        else{
//            estado="libre";
//            return "********** ESTACIONES **********\n"+
//               "\n"+
//               "            ESTADO "+estado+"\n\n";
//        }  
//    }
    
    
}
