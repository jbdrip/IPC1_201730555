package Aereopuerto;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 *
 * @author Javier
 */
public class Frame extends javax.swing.JFrame {
    ListaAviones listaAviones = new ListaAviones();
    ColaPasajeros colaPasajeros = new ColaPasajeros();
    ListaMaletas listaMaletas = new ListaMaletas();
    Graficador g = new Graficador();
    Abecedario abc = new Abecedario();

    int cantAv;
    int cantEst;
    int cantEsc;
    int turno=1;
    int moverPasajero=1;
    int contador = 0;
    int cantidadAv=1;
    int cantidadEs=1;
    String nombreEscritorios="A";

    public Frame() {
        initComponents();
        consola.setEditable(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        empezar = new javax.swing.JButton();
        pasarTurno = new javax.swing.JButton();
        cantAviones = new javax.swing.JTextField();
        cantEstaciones = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        consola = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        cantEscritorios = new javax.swing.JTextField();
        general = new javax.swing.JButton();
        avionesLista = new javax.swing.JButton();
        pasajerosCola = new javax.swing.JButton();
        estacionesLista = new javax.swing.JButton();
        escritoriosLista = new javax.swing.JButton();
        avionesCola = new javax.swing.JButton();
        escritoriosCola = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Aereopuerto");

        empezar.setText("Empezar");
        empezar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                empezarActionPerformed(evt);
            }
        });

        pasarTurno.setText("Pasar Turno");
        pasarTurno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasarTurnoActionPerformed(evt);
            }
        });

        cantAviones.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cantAviones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cantAvionesActionPerformed(evt);
            }
        });

        cantEstaciones.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        consola.setColumns(20);
        consola.setRows(5);
        jScrollPane1.setViewportView(consola);

        jLabel3.setText("Cantidad Aviones:");

        jLabel4.setText("Cantidad Estaciones:");

        jLabel1.setText("Cantidad Escritorios:");

        cantEscritorios.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        general.setText("Vista General");
        general.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                generalActionPerformed(evt);
            }
        });
        general.setEnabled(false);

        avionesLista.setText("Vista llegada de aviones");
        avionesLista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                avionesListaActionPerformed(evt);
            }
        });

        pasajerosCola.setText("Vista desabordaje");
        pasajerosCola.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pasajerosColaActionPerformed(evt);
            }
        });

        estacionesLista.setText("Vista mantenimiento");
        estacionesLista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                estacionesListaActionPerformed(evt);
            }
        });

        escritoriosLista.setText("Vista escritorios registro");
        escritoriosLista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                escritoriosListaActionPerformed(evt);
            }
        });

        avionesCola.setText("Vista cola mantenimiento");
        avionesCola.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                avionesColaActionPerformed(evt);
            }
        });

        escritoriosCola.setText("Vista cola escritorios");
        escritoriosCola.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                escritoriosColaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)
                            .addComponent(jLabel1))
                        .addGap(49, 49, 49)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cantEstaciones, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cantEscritorios, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cantAviones, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(empezar)
                        .addGap(18, 18, 18)
                        .addComponent(pasarTurno))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(escritoriosCola, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(avionesCola, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(escritoriosLista, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(estacionesLista, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(pasajerosCola, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(avionesLista, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(50, 50, 50)
                        .addComponent(general)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 82, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 425, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(cantAviones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(42, 42, 42)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(cantEstaciones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cantEscritorios, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(empezar)
                    .addComponent(pasarTurno))
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(avionesLista)
                    .addComponent(general))
                .addGap(18, 18, 18)
                .addComponent(pasajerosCola)
                .addGap(18, 18, 18)
                .addComponent(estacionesLista)
                .addGap(18, 18, 18)
                .addComponent(escritoriosLista)
                .addGap(18, 18, 18)
                .addComponent(avionesCola)
                .addGap(18, 18, 18)
                .addComponent(escritoriosCola)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(32, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 488, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );

        avionesLista.setEnabled(false);
        pasajerosCola.setEnabled(false);
        estacionesLista.setEnabled(false);
        escritoriosLista.setEnabled(false);
        avionesCola.setEnabled(false);
        escritoriosCola.setEnabled(false);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cantAvionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cantAvionesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cantAvionesActionPerformed

    private void empezarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_empezarActionPerformed
        abc.llenarAbc();
        cantEst=Integer.parseInt(cantEstaciones.getText());
        cantEsc=Integer.parseInt(cantEscritorios.getText());
        consola.append("*************** INICIO TURNO " + turno + "***************");
        consola.append("\n");
        listaAviones.insertarFinal(new Nodo(new Avion(cantidadAv)));
        
        do{
            listaAviones.crearestaciones(new Estacion(cantidadEs));
            cantidadEs++;
        }
        while(cantidadEs<=cantEst);
        
        do{
           listaAviones.crearEscritorios(new Escritorio(abc.abecedario[contador])); 
           contador++;
           cantEsc--;
        }
        while(cantEsc>0);
        
        Nodo aux =listaAviones.colaPasajeros.listaEscritorios.primero;
        while(aux!=null){
               for(int i = 1; i < 8; i++){
                    aux.colaEscritorio.encolar(new Nodo(new EspacioColaEscritorio(i)));
                }
               aux = aux.sig;
           }
        
        listaAviones.recorrer(consola);
        consola.append("*************** FIN TURNO " + turno + "***************");
        consola.append("\n");
        cantidadEs--;
        
        g.crearDotAvion(listaAviones.primero, "ListaAviones");
        g.genImagen("ListaAviones.dot", "ListaAviones.png");
        
        g.crearDotPasajero(listaAviones.colaPasajeros.primero, "ColaPasajeros");
        g.genImagen("ColaPasajeros.dot", "ColaPasajeros.png");
        
//        g.crearDotMaletas(listaAviones.colaPasajeros.listaMaletas.primero, "ListaMaletas");
//        g.genImagen("ListaMaletas.dot", "ListaMaletas.png");

        g.crearDotEscritorios(listaAviones.colaPasajeros.listaEscritorios.primero, "ListaEscritorios");
        g.genImagen("ListaEscritorios.dot", "ListaEscritorios.png");
        
        g.crearDotEstaciones(listaAviones.colaAviones.listaEstaciones.primero, "ListaEstaciones");
        g.genImagen("ListaEstaciones.dot", "ListaEstaciones.png");
        
        g.crearDotColaAviones(listaAviones.colaAviones.primero, "ColaAviones");
        g.genImagen("ColaAviones.dot", "ColaAviones.png");
        
        g.crearDotColaEscritorio(listaAviones.colaPasajeros.listaEscritorios.primero.colaEscritorio.primero, "ColaEscritorio");
        g.genImagen("ColaEscritorio.dot", "ColaEscritorio.png");
        
        empezar.setEnabled(false);
        general.setEnabled(true);
        avionesLista.setEnabled(true);
        pasajerosCola.setEnabled(true);
        estacionesLista.setEnabled(true);
        escritoriosLista.setEnabled(true);
        avionesCola.setEnabled(true);
        escritoriosCola.setEnabled(true);
    }//GEN-LAST:event_empezarActionPerformed

    private void pasarTurnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasarTurnoActionPerformed
        cantAv = Integer.parseInt(cantAviones.getText());
        cantidadAv++;
        turno++;
        consola.append("*************** INICIO TURNO " + turno + "***************");
        consola.append("\n");                                          
        listaAviones.pasarTurnoDes();
        listaAviones.eliminar();
//        for(int i=0; i<5; i++){
//            listaAviones.colaPasajeros.eliminar();
//        }
        
        if (cantidadAv <= cantAv) {
            listaAviones.insertarFinal(new Nodo(new Avion(cantidadAv)));
        }
        listaAviones.procesosestaciones();
        listaAviones.procesosEscritorios();
        
        listaAviones.recorrer(consola);
        consola.append("*************** FIN TURNO " + turno + "***************");
        consola.append("\n");
        
        g.crearDotAvion(listaAviones.primero, "ListaAviones");
        g.genImagen("ListaAviones.dot", "ListaAviones.png");
        
        g.crearDotPasajero(listaAviones.colaPasajeros.primero, "ColaPasajeros");
        g.genImagen("ColaPasajeros.dot", "ColaPasajeros.png");
        
//        g.crearDotMaletas(listaAviones.colaPasajeros.listaMaletas.primero, "ListaMaletas");
//        g.genImagen("ListaMaletas.dot", "ListaMaletas.png");

        g.crearDotEscritorios(listaAviones.colaPasajeros.listaEscritorios.primero, "ListaEscritorios");
        g.genImagen("ListaEscritorios.dot", "ListaEscritorios.png");
        
        g.crearDotEstaciones(listaAviones.colaAviones.listaEstaciones.primero, "ListaEstaciones");
        g.genImagen("ListaEstaciones.dot", "ListaEstaciones.png");
        
        g.crearDotColaAviones(listaAviones.colaAviones.primero, "ColaAviones");
        g.genImagen("ColaAviones.dot", "ColaAviones.png");
        
        g.crearDotColaEscritorio(listaAviones.colaPasajeros.listaEscritorios.primero.colaEscritorio.primero, "ColaEscritorio");
        g.genImagen("ColaEscritorio.dot", "ColaEscritorio.png");
    }//GEN-LAST:event_pasarTurnoActionPerformed

    private void generalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_generalActionPerformed
        // TODO add your handling code here:
        Visor v = new Visor();
        v.setSize(800,750);
        
        ImageIcon image = new ImageIcon("ListaAviones.png");
        image.getImage().flush();
        v.labelAviones.setIcon(image);
        
        ImageIcon image1 = new ImageIcon("ColaPasajeros.png");
        image1.getImage().flush();
        v.labelPasajeros.setIcon(image1);
        
        ImageIcon image2 = new ImageIcon("ListaEstaciones.png");
        image2.getImage().flush();
        v.labelEstaciones.setIcon(image2);
        
        ImageIcon image3 = new ImageIcon("ListaEscritorios.png");
        image3.getImage().flush();
        v.labelEscritorios.setIcon(image3);
        
        ImageIcon image4 = new ImageIcon("ColaAviones.png");
        image4.getImage().flush();
        v.labelColaAviones.setIcon(image4);
        
        ImageIcon image5 = new ImageIcon("ColaEscritorio.png");
        image5.getImage().flush();
        v.labelColaEscritorios.setIcon(image5);
        
        v.setVisible(true);
    }//GEN-LAST:event_generalActionPerformed

    private void avionesListaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_avionesListaActionPerformed
        // TODO add your handling code here:
        VisorAviones v = new VisorAviones();
        v.setSize(300,450);
        
        ImageIcon image = new ImageIcon("ListaAviones.png");
        image.getImage().flush();
        v.labelAviones.setIcon(image);
        
        v.setVisible(true);
    }//GEN-LAST:event_avionesListaActionPerformed

    private void pasajerosColaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pasajerosColaActionPerformed
        // TODO add your handling code here:
        VisorPasajeros v = new VisorPasajeros();
        v.setSize(300,450);
        
        ImageIcon image1 = new ImageIcon("ColaPasajeros.png");
        image1.getImage().flush();
        v.labelPasajeros.setIcon(image1);
        
        v.setVisible(true);
    }//GEN-LAST:event_pasajerosColaActionPerformed

    private void estacionesListaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_estacionesListaActionPerformed
        // TODO add your handling code here:
        VisorEstaciones v = new VisorEstaciones();
        v.setSize(300,450);
        
        ImageIcon image2 = new ImageIcon("ListaEstaciones.png");
        image2.getImage().flush();
        v.labelEstaciones.setIcon(image2);
        
        v.setVisible(true);
    }//GEN-LAST:event_estacionesListaActionPerformed

    private void escritoriosListaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_escritoriosListaActionPerformed
        // TODO add your handling code here:
        VisorEscritorios v = new VisorEscritorios();
        v.setSize(400,450);
        
        ImageIcon image3 = new ImageIcon("ListaEscritorios.png");
        image3.getImage().flush();
        v.labelEscritorios.setIcon(image3);
        
        v.setVisible(true);
    }//GEN-LAST:event_escritoriosListaActionPerformed

    private void avionesColaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_avionesColaActionPerformed
        // TODO add your handling code here:
        VisorColaEstaciones v = new VisorColaEstaciones();
        v.setSize(300,450);
        
        ImageIcon image4 = new ImageIcon("ColaAviones.png");
        image4.getImage().flush();
        v.labelColaAviones.setIcon(image4);
        
        v.setVisible(true);
    }//GEN-LAST:event_avionesColaActionPerformed

    private void escritoriosColaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_escritoriosColaActionPerformed
        // TODO add your handling code here:
        VisorColaEscritorios v = new VisorColaEscritorios();
        v.setSize(300,450);
        
        ImageIcon image5 = new ImageIcon("ColaEscritorio.png");
        image5.getImage().flush();
        v.labelColaEscritorios.setIcon(image5);
        
        v.setVisible(true);
    }//GEN-LAST:event_escritoriosColaActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Frame().setVisible(true);

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton avionesCola;
    private javax.swing.JButton avionesLista;
    public static javax.swing.JTextField cantAviones;
    private javax.swing.JTextField cantEscritorios;
    public static javax.swing.JTextField cantEstaciones;
    private javax.swing.JTextArea consola;
    private javax.swing.JButton empezar;
    private javax.swing.JButton escritoriosCola;
    private javax.swing.JButton escritoriosLista;
    private javax.swing.JButton estacionesLista;
    private javax.swing.JButton general;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton pasajerosCola;
    private javax.swing.JButton pasarTurno;
    // End of variables declaration//GEN-END:variables
}
