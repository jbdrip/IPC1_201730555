/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aereopuerto;

import javax.swing.JTextArea;

/**
 *
 * @author Javier
 */
public class ListaAviones {

    public Nodo primero;
    int cantpasajeros = 0;
    
    ColaPasajeros colaPasajeros = new ColaPasajeros();
    ColaAviones colaAviones = new ColaAviones();
    ColaEscritorios colaEscritorios = new ColaEscritorios();
    ListaEscritorios listaEscritorios = new ListaEscritorios();

    public void insertarInicio(Nodo nuevo) {
        if (primero == null) {
            primero = nuevo;
        } else {
            nuevo.sig = primero;
            primero.ant = nuevo;
            primero = nuevo;
        }
    }

    public void pasarTurnoDes() {
        if (primero == null) {
            System.out.println("No hay aviones");
        } else {
            Nodo aux = primero;
            while (aux != null) {
                Avion av = (Avion) aux.getDato();
                av.cantTurnosDes=(av.cantTurnosDes-1);
                aux = aux.sig;
            }
        }
    }

    public void descolarPasajeros() {
        colaPasajeros.descolar();
    }
    
    public void crearestaciones(Estacion estacion){
        colaAviones.crearestacion(estacion);
    }
    
    public void crearEscritorios(Escritorio escritorio){
        colaPasajeros.crearEscritorio(escritorio);
    }
    
    public void procesosestaciones(){
        colaAviones.procesosmantenimiento();
        colaAviones.descolar();
    }

    public void procesosEscritorios(){
        colaPasajeros.procesosmantenimiento();
        for(int i=0; i<5; i++){
            colaPasajeros.descolar();
        }
    }

    public void insertarFinal(Nodo nuevo) {
        Nodo aux = primero;
        if (primero == null) {
            primero = nuevo;
            Avion av = (Avion) primero.getDato();
            cantpasajeros = av.getCantPasajeros();
            for (int i = 1; i <= cantpasajeros; i++) {
                colaPasajeros.encolar(new Nodo(new Pasajero(i)));
            }
            cantpasajeros++;
        } else {
            int cantpasajeros2 = cantpasajeros - 1;
            while (aux.sig != null) {
                aux = aux.sig;
            }
            aux.sig = nuevo;
            Avion avi = (Avion) aux.sig.getDato();
            cantpasajeros2 = cantpasajeros2 + avi.getCantPasajeros();
            nuevo.ant = aux;
            for (; cantpasajeros <= cantpasajeros2; cantpasajeros++) {
                colaPasajeros.encolar(new Nodo(new Pasajero(cantpasajeros)));
            }
        }

    }

    public void eliminar() {
        try{
        if (primero != null) {
            Nodo aux = primero;
            Nodo antaux = null;
            while (aux != null) {
                Avion av = (Avion) aux.getDato();
                if (av.getCantTurnosDes() == 0) {
                    if (antaux == null) {
                        colaAviones.encolar(aux);
                        primero = primero.sig;
                        aux.sig = null;
                        aux = primero;
                    } else {
                        antaux.sig = aux.sig;
                        aux.sig = null;
                        aux = antaux.sig;
                        aux.ant = antaux;
                    }
                } else {
                    antaux = aux;
                    aux = aux.sig;
                }
            }
        }
        }catch(Exception e){}
    }

    public void recorrer(JTextArea txt) {
        if (primero == null) {
            txt.append("**********Aviones**********");
            txt.append("\nNo hay aviones");
        } else {
            Nodo aux = primero;
            txt.append("**********Aviones**********");
            while (aux != null) {
                Avion av = (Avion) aux.getDato();
                txt.append("\nAvion " + av.getCorrelativo()
                        + "\n       Tipo: " + av.getTipo()
                        + "\n       Pasajeros: " + av.getCantPasajeros()
                        + "\n       Desabordaje: " + av.getCantTurnosDes()
                        + "\n       Mantenimiento: " + av.getCantTurnosMan());
                aux = aux.sig;
            }
        }
        
        txt.append("\n");
        colaPasajeros.recorrer(txt);
        txt.append("\n");
        colaAviones.recorrer(txt);

    }
}
