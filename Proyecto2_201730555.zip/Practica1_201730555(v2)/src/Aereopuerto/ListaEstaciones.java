/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aereopuerto;

import javax.swing.JTextArea;

/**
 *
 * @author Javier
 */
public class ListaEstaciones {

    int estacionLibre = 0;
    public Nodo primero;

    public void insertarFinal(Nodo mantenimiento) {
        Nodo aux = primero;
        if (primero == null) {
            primero = mantenimiento;
        } else {
            while (aux.sig != null) {
                aux = aux.sig;
            }
            aux.sig = mantenimiento;
        }
    }

    public void eliminarEstacionLibre(Nodo avion) {
        Nodo actualEstacion = primero;
        while (actualEstacion != null) {
            Estacion aux = (Estacion) actualEstacion.getDato();
            Avion encola = (Avion) avion.getDato();
            if (aux.getEstado().equals("Libre")) {
                aux.setEstado("Ocupado");
                aux.setNumAvion(encola.getCorrelativo());
                aux.setTipo(encola.getTipo());
                aux.setPasajeros(encola.getCantPasajeros());
                aux.setTurnosDesabordaje(encola.getCantTurnosDes());
                aux.setMantenimiento(encola.getCantTurnosMan());
                actualEstacion = null;
            } else {
                actualEstacion = actualEstacion.sig;
            }
        }
    }

    public void pasarTurnoMan() {
        if (primero == null) {
            System.out.println("No hay estaciones");
        } else {
            Nodo aux = primero;
            while (aux != null) {
                Estacion estacion = (Estacion) aux.getDato();
                if(estacion.getEstado().equals("Ocupado")){
                estacion.mantenimiento=(estacion.mantenimiento-1);
                }
                aux = aux.sig;
            }
        }
    }

    public void eliminarEstacionOcupada() {
        Nodo actual = primero;
        while (actual != null) {
            Estacion aux = (Estacion) actual.getDato();
            if ((aux.getEstado().equals("Ocupado")) && (aux.getMantenimiento() <= 0)) {
                aux.setEstado("Libre");
                aux.setNumAvion(0);
                aux.setTipo("");
                aux.setPasajeros(0);
                aux.setTurnosDesabordaje(0);
                aux.setMantenimiento(0);
                actual = null;
            } else {
                actual = actual.sig;
            }
        }
    }

    public void recorrer() {
        if (primero == null) {
            System.out.println("**********Estaciones**********");
            System.out.println("No hay Aviones");
        } else {
            Nodo mantenimiento = primero;
            
            System.out.println("**********Estaciones**********");
            while (mantenimiento != null) {
                Estacion aux = (Estacion) mantenimiento.getDato();
                System.out.println("Estacion: " + aux.getCorrelativo()
                        + "\n       Estado: " + aux.getEstado()
                        + "\n       Avion: " + aux.getNumAvion()
                        + "\n       Tipo: " + aux.getTipo()
                        + "\n       Pasajeros: " + aux.getPasajeros()
                        + "\n       Desabordaje: " + aux.getTurnosDesabordaje()
                        + "\n       Mantenimiento: " + aux.getMantenimiento());
                mantenimiento = mantenimiento.sig;
            }
        }
        System.out.println("");
    }

    public void recorrer(JTextArea txt) {
        if (primero == null) {
            txt.append("**********Estaciones**********");
            txt.append("\nNo hay Aviones");
        } else {
            Nodo mantenimiento = primero;
            txt.append("**********Estaciones**********");
            while (mantenimiento!= null) {
                Estacion aux = (Estacion) mantenimiento.getDato();
                txt.append("\nEstacion: " + aux.getCorrelativo()
                        + "\n       Estado: " + aux.getEstado()
                        + "\n       Avion: " + aux.getNumAvion()
                        + "\n       Tipo: " + aux.getTipo()
                        + "\n       Pasajeros: " + aux.getPasajeros()
                        + "\n       Desabordaje: " + aux.getTurnosDesabordaje()
                        + "\n       Mantenimiento: " + aux.getMantenimiento());
                mantenimiento = mantenimiento.sig;
            }
            txt.append("\n");
        }
    }
}
